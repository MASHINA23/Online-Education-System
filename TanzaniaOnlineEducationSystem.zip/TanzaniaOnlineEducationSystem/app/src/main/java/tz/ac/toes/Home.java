package tz.ac.toes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import com.ToxicBakery.viewpager.transforms.AccordionTransformer;
import com.ToxicBakery.viewpager.transforms.CubeOutTransformer;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.material.appbar.AppBarLayout;

public class Home extends AppCompatActivity implements courses.OnFragmentInteractionListener, discussions.OnFragmentInteractionListener,
universities.OnFragmentInteractionListener {
    private ViewPager extendedViewPager;
    private FragmentPagerAdapter adapterViewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        extendedViewPager = findViewById(R.id.vpPager);
        this.adapterViewPager = new Wambura(getSupportFragmentManager());
        extendedViewPager.setAdapter(this.adapterViewPager);
        extendedViewPager.setPageTransformer(true, new CubeOutTransformer());
        extendedViewPager.setOffscreenPageLimit(5);
        extendedViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    default:
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }
    private class Wambura extends FragmentPagerAdapter {

        private Wambura(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public int getCount() {
            return 3;
        }
        @Override
        public int getItemPosition(Object object){
            return POSITION_NONE;
        }
        @Override
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return courses.newInstance(Constants.userid+"", "courses");
                case 1:
                    return universities.newInstance(Constants.userid+"", "schools");
                case 2:
                    return discussions.newInstance(Constants.userid+"", "discussions");
                default:
                    return courses.newInstance(Constants.userid+"","");
            }
        }
        public CharSequence getPageTitle(int i) {
            StringBuilder sb = new StringBuilder();
            sb.append("Page ");
            sb.append(i);
            return sb.toString();
        }
    }
    @Override
        public void onFragmentInteraction(Uri uri) {
        }
        public void OnChangeCurrentView(int page){
            OnChangeViewPager(page);
        }
        public void OnChangeViewPager(int pageno) {
            extendedViewPager.setCurrentItem(pageno);
        }
}
package tz.ac.toes;

public class Constants {
    static int userid = 1;
}

package tz.ac.toes;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

public class MainActivity extends AppCompatActivity {
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView d = findViewById(R.id.pro);
        Glide.with(this).load(R.drawable.educationallogo).circleCrop().into(d);

        RelativeLayout signin = findViewById(R.id.signin);
        RelativeLayout signup = findViewById(R.id.signup);
        signin.setFocusableInTouchMode(true);
        Button buttonsignin = findViewById(R.id.signnow);
        Button buttonsignup = findViewById(R.id.signupnow);
        MaterialTextView buttonsupchange = findViewById(R.id.supchange);
        MaterialTextView buttonsinchange = findViewById(R.id.sinchange);
        LinearLayout loadlayout = findViewById(R.id.loader);
        ImageView loadImage = findViewById(R.id.loaderin);
        TextInputEditText emailogin = findViewById(R.id.loginemail);
        TextInputEditText passlogin = findViewById(R.id.loginemail);
        buttonsignin.setOnClickListener(sinchange->{
            yoyoShow(loadlayout);
            Glide.with(loadImage).asGif().circleCrop().load(R.drawable.load).into(loadImage);
            if(!emailogin.getText().toString().equals("")){
                new Handler().postDelayed(()->{
                    Intent home = new Intent(this, Home.class);
                    startActivity(home);
                    yoyoHide(loadlayout);
                }, 15000);
                return;
            }
            Snackbar.make(getWindow().getDecorView(),"Fill All The Fields", BaseTransientBottomBar.LENGTH_LONG)
                    .setBackgroundTint(getResources().getColor(R.color.colorAlt))
                    .setTextColor(getResources().getColor(R.color.colorAccent)).show();
            yoyoHide(loadlayout);
        });
        buttonsignup.setOnClickListener(sinchange->{
            yoyoShow(loadlayout);
            Glide.with(loadImage).asGif().circleCrop().into(loadImage);
        });
        buttonsinchange.setOnClickListener(sin-> {
            yoyoShow(signin);
            yoyoHide(signup);
        });
        buttonsupchange.setOnClickListener(sup-> {
            yoyoShow(signup);
            yoyoHide(signin);
        });
    }
    private void yoyoShow(View view) {
        YoYo.with(Techniques.FadeIn).duration(300).onStart(onstart->{
            view.setVisibility(View.VISIBLE);
        }).playOn(view);
    }
    private void yoyoHide(View view) {
        YoYo.with(Techniques.FadeOut).duration(300).onEnd(onend->{
            view.setVisibility(View.GONE);
        }).playOn(view);
    }
}